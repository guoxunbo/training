#Client开发环境搭建以及目录介绍
@(VCIMSoft)

-------------------
[TOC]
##安装Node.js
###下载并配置卸载的镜像源
>前往`node.js`[官网](http://nodejs.cn/download/)下载并安装工具
![Alt text](./1590730592856.png) 
>下载完成一直下一步安装即可。安装完毕使用`npm -v`进行验证是否安装成功。
![Alt text](./1590730864306.png)
> 配置淘宝的镜像仓库
```bash
npm config set registry=http://registry.npm.taobao.org
```
> 配置完成用`npm config get registry`验证下是否配置成功
![Alt text](./1590730991164.png)
### 启动
> 到`Client`项目目录下如`C:\Users\guoxunbo\Desktop\client`执行如下命令
```bash
npm install
```
![Alt text](./1590731239905.png)
> `Install`完成之后就可以启动了. 默认启动的是`Local`即本地开发环境。
```bash
npm start
```
![Alt text](./1590731587995.png)
### 打包
> 到`Client`项目目录下如`C:\Users\guoxunbo\Desktop\client`执行如下命令
```bash
npm run-script build
```
![Alt text](./1590731628182.png)
![Alt text](./1590731652129.png)
会在项目的`build`目录生成相应的打包好的文件。
![Alt text](./1590731704264.png)
## 安装Visual Studio Code
>前往`Visual Studio Code`[官网](https://code.visualstudio.com/)下载并安装工具
![Alt text](./1590731844504.png)
